# 공유 개발 DB 환경 설정 가이드

Team-PICK-O 프로젝트에서 팀원들이 동일한 DB를 공유하여 개발할 수 있도록 설정하는 가이드입니다.

## 🏗️ 아키텍처

```
서버 컴퓨터 (1대)
├── docker-compose.shared.yml
│   ├── PostgreSQL DB (포트 5432 개방)
│   └── pgAdmin (포트 8080 개방)
│   # └── Redis (사용하지 않음)

팀원 로컬 환경 (N대)
├── Backend (Django) - 원격 DB 접근
├── Frontend (React/Vue) - 로컬 실행
└── .env.local - 서버 IP 설정
```

## 🚀 서버 설정 (DB 호스팅 담당자)

### 1. 공유 DB 컨테이너 실행

```bash
cd deployment

# 공유 DB 환경 시작
docker-compose -f docker-compose.shared.yml up -d

# 상태 확인
docker-compose -f docker-compose.shared.yml ps
```

### 2. 방화벽 포트 개방

**macOS:**
```bash
# 방화벽 비활성화 (개발 환경만)
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --setglobalstate off
```

**Linux (Ubuntu):**
```bash
# PostgreSQL 포트 개방
sudo ufw allow 5432/tcp
# pgAdmin 포트 개방  
sudo ufw allow 8080/tcp
# Redis는 사용하지 않음 (주석 처리됨)
# sudo ufw allow 6379/tcp
```

**Windows:**
- 고급 보안이 포함된 Windows Defender 방화벽에서 5432, 8080 포트 개방

### 3. 서버 IP 확인

```bash
# 로컬 네트워크 IP 확인
ip addr show | grep "inet "  # Linux
ifconfig | grep "inet "      # macOS
ipconfig                     # Windows
```

### 4. 백업 설정

```bash
# 백업 스크립트 실행 권한 부여
chmod +x backup-db.sh

# 수동 백업 실행
./backup-db.sh

# cron으로 자동 백업 설정 (매일 새벽 2시)
crontab -e
# 아래 라인 추가:
# 0 2 * * * /path/to/deployment/backup-db.sh
```

## 👥 팀원 로컬 설정

### 1. 환경설정 파일 수정

```bash
# backend 디렉토리에서
cp .env.local .env

# .env 파일에서 YOUR_SERVER_IP_HERE를 실제 서버 IP로 변경
# 예: DB_HOST=192.168.1.100
```

### 2. DB 연결 테스트

```bash
# Django에서 DB 연결 테스트
cd backend
python manage.py dbshell
```

### 3. 개발 서버 실행

```bash
# 백엔드 (Django)
cd backend
python manage.py runserver 0.0.0.0:8000

# 프론트엔드
cd frontend
npm run dev
```

## 🔧 접근 방법

### pgAdmin 웹 접근
- URL: `http://서버IP:8080`
- Email: `admin@picko.com`
- Password: `picko1q2w3e4r`

### 직접 DB 접속
- Host: `서버IP`
- Port: `5432`
- Database: `teamPicko`
- Username: `teamPicko`
- Password: `picko1q2w3e4r`

## 🔒 보안 고려사항

### 현재 설정 (개발용)
- 간단한 패스워드 사용
- 모든 IP에서 접근 가능

### 권장 개선사항 (프로덕션 준비시)
```bash
# 1. 강한 패스워드 설정
POSTGRES_PASSWORD=strong_random_password_here

# 2. 특정 IP만 허용 (방화벽 또는 PostgreSQL 설정)
# postgresql.conf: listen_addresses = 'localhost,팀원IP1,팀원IP2'

# 3. SSL 연결 강제
# postgresql.conf: ssl = on
```

## 🛠️ 트러블슈팅

### 연결 안 됨
```bash
# 포트 열려있는지 확인
telnet 서버IP 5432

# 컨테이너 로그 확인
docker-compose -f docker-compose.shared.yml logs database
```

### 백업 복원
```bash
# 백업에서 DB 복원
gunzip backups/teamPicko_backup_YYYYMMDD_HHMMSS.sql.gz
docker exec -i teamPicko-shared-db psql -U teamPicko -d teamPicko < backups/teamPicko_backup_YYYYMMDD_HHMMSS.sql
```

### 데이터 초기화
```bash
# 모든 데이터 삭제 후 재시작
docker-compose -f docker-compose.shared.yml down -v
docker-compose -f docker-compose.shared.yml up -d
```

## 📝 주의사항

1. **데이터 공유**: 모든 팀원이 같은 DB를 사용하므로 테스트 데이터 생성/삭제시 주의
2. **마이그레이션**: 모델 변경시 팀원들과 협의 후 진행
3. **백업**: 중요한 작업 전 반드시 백업 실행
4. **서버 다운**: 서버 컴퓨터 종료시 모든 팀원 개발 중단