# Google Drive API 설정 가이드

Google Drive 자동 백업을 위한 API 설정 방법입니다.

## 🔧 1. Google Cloud Console 설정

### 1-1. 프로젝트 생성
1. [Google Cloud Console](https://console.cloud.google.com/) 접속
2. 새 프로젝트 생성: "TeamPicko-Backup"
3. 프로젝트 선택

### 1-2. Google Drive API 활성화
1. "API 및 서비스" > "라이브러리" 메뉴
2. "Google Drive API" 검색 후 활성화

### 1-3. 서비스 계정 생성
1. "API 및 서비스" > "사용자 인증 정보" 메뉴
2. "+ 사용자 인증 정보 만들기" > "서비스 계정"
3. 서비스 계정 정보:
   - 이름: `teamPicko-backup-service`
   - ID: `teamPicko-backup-service`
   - 설명: `TeamPicko DB 백업용 서비스 계정`

### 1-4. 서비스 계정 키 생성
1. 생성된 서비스 계정 클릭
2. "키" 탭 > "키 추가" > "새 키 만들기"
3. **JSON** 형식 선택
4. 다운로드된 JSON 파일을 `google-drive-credentials.json`으로 이름 변경
5. `deployment/` 폴더에 저장

## 🔗 2. Google Drive 폴더 준비

### 2-1. 백업 폴더 생성
1. Google Drive에서 `TeamPicko-DB-Backups` 폴더 생성
2. 폴더 우클릭 > "공유" 선택
3. 서비스 계정 이메일 주소를 **편집자** 권한으로 추가
   - 이메일: `teamPicko-backup-service@프로젝트ID.iam.gserviceaccount.com`

### 2-2. 폴더 ID 확인
1. 백업 폴더 열기
2. 주소창에서 폴더 ID 복사
   - URL: `https://drive.google.com/drive/folders/1A2B3C4D5E6F7G8H9I`
   - 폴더 ID: `1A2B3C4D5E6F7G8H9I`

## 📝 3. 환경 설정

`deployment/.env.backup` 파일 생성:
```env
GOOGLE_DRIVE_FOLDER_ID=여기에_폴더ID_입력
GOOGLE_CREDENTIALS_FILE=google-drive-credentials.json
```

## ⚠️ 보안 주의사항

1. `google-drive-credentials.json` 파일을 Git에 커밋하지 마세요!
2. `.gitignore`에 추가:
   ```
   google-drive-credentials.json
   .env.backup
   ```

## 🧪 4. 테스트

설정 완료 후 `test-google-drive.py` 실행하여 연결 테스트