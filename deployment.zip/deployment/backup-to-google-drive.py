#!/usr/bin/env python3
"""
TeamPicko 데이터베이스 Google Drive 자동 백업 스크립트
월~금 저녁 6시에 실행되도록 스케줄링
"""

import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

try:
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    from google.oauth2.service_account import Credentials
except ImportError:
    print("❌ Google API 패키지가 설치되지 않았습니다.")
    print("다음 명령어로 설치하세요: pip install -r requirements-backup.txt")
    sys.exit(1)

# 환경 변수 로드
load_dotenv('.env.backup')

# 설정
CONTAINER_NAME = "teamPicko-shared-db"
DB_NAME = "teamPicko"
DB_USER = "teamPicko"
BACKUP_DIR = Path("./backups")
GOOGLE_CREDENTIALS_FILE = os.getenv('GOOGLE_CREDENTIALS_FILE', 'google-drive-credentials.json')
GOOGLE_DRIVE_FOLDER_ID = os.getenv('GOOGLE_DRIVE_FOLDER_ID')

def log_message(message):
    """로그 메시지 출력"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] {message}")

def create_sql_backup():
    """PostgreSQL 데이터베이스를 SQL 파일로 백업"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_file = BACKUP_DIR / f"teamPicko_backup_{timestamp}.sql"
    
    # 백업 디렉토리 생성
    BACKUP_DIR.mkdir(exist_ok=True)
    
    log_message("SQL 백업 시작...")
    
    try:
        # Docker 컨테이너에서 pg_dump 실행
        cmd = [
            "docker", "exec", "-t", CONTAINER_NAME,
            "pg_dump", "-c", "-U", DB_USER, DB_NAME
        ]
        
        with open(backup_file, 'w', encoding='utf-8') as f:
            result = subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, text=True)
        
        if result.returncode == 0:
            log_message(f"✅ SQL 백업 완료: {backup_file}")
            return backup_file
        else:
            log_message(f"❌ SQL 백업 실패: {result.stderr}")
            if backup_file.exists():
                backup_file.unlink()
            return None
            
    except Exception as e:
        log_message(f"❌ SQL 백업 중 오류: {e}")
        return None

def upload_to_google_drive(file_path):
    """파일을 Google Drive에 업로드"""
    if not Path(GOOGLE_CREDENTIALS_FILE).exists():
        log_message(f"❌ Google Drive 인증 파일을 찾을 수 없습니다: {GOOGLE_CREDENTIALS_FILE}")
        return False
    
    if not GOOGLE_DRIVE_FOLDER_ID:
        log_message("❌ GOOGLE_DRIVE_FOLDER_ID가 설정되지 않았습니다.")
        return False
    
    try:
        # Google Drive API 인증
        credentials = Credentials.from_service_account_file(
            GOOGLE_CREDENTIALS_FILE,
            scopes=['https://www.googleapis.com/auth/drive.file']
        )
        service = build('drive', 'v3', credentials=credentials)
        
        # 파일 정보
        file_name = file_path.name
        
        # 파일 메타데이터
        file_metadata = {
            'name': file_name,
            'parents': [GOOGLE_DRIVE_FOLDER_ID]
        }
        
        # 파일 업로드
        media = MediaFileUpload(str(file_path), mimetype='application/sql')
        
        log_message(f"Google Drive에 업로드 중: {file_name}")
        
        uploaded_file = service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id,name,size,createdTime'
        ).execute()
        
        # 업로드 완료 정보
        file_size = int(uploaded_file.get('size', 0))
        file_size_mb = file_size / (1024 * 1024)
        
        log_message(f"✅ Google Drive 업로드 완료:")
        log_message(f"   - 파일명: {uploaded_file.get('name')}")
        log_message(f"   - 파일 ID: {uploaded_file.get('id')}")
        log_message(f"   - 크기: {file_size_mb:.2f} MB")
        log_message(f"   - 업로드 시간: {uploaded_file.get('createdTime')}")
        
        return True
        
    except Exception as e:
        log_message(f"❌ Google Drive 업로드 실패: {e}")
        return False

def cleanup_old_backups():
    """7일 이상 된 로컬 백업 파일 삭제"""
    try:
        if not BACKUP_DIR.exists():
            return
            
        cutoff_time = datetime.now().timestamp() - (7 * 24 * 3600)  # 7일 전
        deleted_count = 0
        
        for backup_file in BACKUP_DIR.glob("teamPicko_backup_*.sql"):
            if backup_file.stat().st_mtime < cutoff_time:
                backup_file.unlink()
                deleted_count += 1
        
        if deleted_count > 0:
            log_message(f"🗑️ 오래된 로컬 백업 파일 {deleted_count}개 삭제")
            
    except Exception as e:
        log_message(f"⚠️ 로컬 백업 파일 정리 중 오류: {e}")

def cleanup_old_google_drive_backups(service, days=30):
    """30일 이상 된 Google Drive 백업 파일 삭제"""
    try:
        from datetime import timedelta
        
        cutoff_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        # 오래된 백업 파일 검색
        query = f"parents='{GOOGLE_DRIVE_FOLDER_ID}' and name contains 'teamPicko_backup_' and createdTime < '{cutoff_date}'"
        
        results = service.files().list(
            q=query,
            fields='files(id,name,createdTime)'
        ).execute()
        
        old_files = results.get('files', [])
        
        for file in old_files:
            service.files().delete(fileId=file['id']).execute()
            log_message(f"🗑️ Google Drive에서 오래된 백업 삭제: {file['name']}")
            
        if old_files:
            log_message(f"🗑️ Google Drive에서 오래된 백업 파일 {len(old_files)}개 삭제")
            
    except Exception as e:
        log_message(f"⚠️ Google Drive 백업 파일 정리 중 오류: {e}")

def main():
    """메인 백업 프로세스"""
    log_message("=" * 60)
    log_message("TeamPicko DB Google Drive 백업 시작")
    log_message("=" * 60)
    
    # 현재 요일 확인 (월:0, 화:1, ..., 일:6)
    current_weekday = datetime.now().weekday()
    if current_weekday >= 5:  # 토(5), 일(6)
        log_message("주말에는 백업을 실행하지 않습니다.")
        return
    
    # 1. SQL 백업 생성
    backup_file = create_sql_backup()
    if not backup_file:
        log_message("❌ 백업 프로세스 중단: SQL 백업 실패")
        return
    
    # 2. Google Drive에 업로드
    upload_success = upload_to_google_drive(backup_file)
    if not upload_success:
        log_message("❌ Google Drive 업로드 실패")
        return
    
    # 3. 로컬 백업 파일 정리
    cleanup_old_backups()
    
    # 4. Google Drive 백업 파일 정리 (30일 이상)
    try:
        credentials = Credentials.from_service_account_file(
            GOOGLE_CREDENTIALS_FILE,
            scopes=['https://www.googleapis.com/auth/drive.file']
        )
        service = build('drive', 'v3', credentials=credentials)
        cleanup_old_google_drive_backups(service, days=30)
    except Exception as e:
        log_message(f"⚠️ Google Drive 정리 중 오류: {e}")
    
    log_message("=" * 60)
    log_message("TeamPicko DB Google Drive 백업 완료")
    log_message("=" * 60)

if __name__ == "__main__":
    main()