#!/usr/bin/env python3
"""
Google Drive API 연결 테스트 스크립트
백업 시스템 설정 후 연결을 테스트합니다.
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

try:
    from googleapiclient.discovery import build
    from google.oauth2.service_account import Credentials
except ImportError:
    print("❌ Google API 패키지가 설치되지 않았습니다.")
    print("다음 명령어로 설치하세요: pip install -r requirements-backup.txt")
    sys.exit(1)

# 환경 변수 로드
load_dotenv('.env.backup')

GOOGLE_CREDENTIALS_FILE = os.getenv('GOOGLE_CREDENTIALS_FILE', 'google-drive-credentials.json')
GOOGLE_DRIVE_FOLDER_ID = os.getenv('GOOGLE_DRIVE_FOLDER_ID')

def test_google_drive_connection():
    """Google Drive API 연결 테스트"""
    print("🔧 Google Drive API 연결 테스트")
    print("=" * 50)
    
    # 1. 환경 변수 확인
    print("1. 환경 변수 확인:")
    print(f"   - GOOGLE_CREDENTIALS_FILE: {GOOGLE_CREDENTIALS_FILE}")
    print(f"   - GOOGLE_DRIVE_FOLDER_ID: {GOOGLE_DRIVE_FOLDER_ID}")
    
    if not GOOGLE_DRIVE_FOLDER_ID:
        print("❌ GOOGLE_DRIVE_FOLDER_ID가 설정되지 않았습니다.")
        return False
    
    # 2. 인증 파일 확인
    print("\n2. 인증 파일 확인:")
    credentials_path = Path(GOOGLE_CREDENTIALS_FILE)
    if not credentials_path.exists():
        print(f"❌ 인증 파일을 찾을 수 없습니다: {GOOGLE_CREDENTIALS_FILE}")
        return False
    print(f"✅ 인증 파일 존재: {credentials_path.absolute()}")
    
    # 3. Google Drive API 연결 테스트
    print("\n3. Google Drive API 연결 테스트:")
    try:
        credentials = Credentials.from_service_account_file(
            GOOGLE_CREDENTIALS_FILE,
            scopes=['https://www.googleapis.com/auth/drive.file']
        )
        service = build('drive', 'v3', credentials=credentials)
        print("✅ Google Drive API 인증 성공")
        
        # 4. 백업 폴더 접근 테스트
        print("\n4. 백업 폴더 접근 테스트:")
        folder_info = service.files().get(
            fileId=GOOGLE_DRIVE_FOLDER_ID,
            fields='id,name,permissions'
        ).execute()
        
        print(f"✅ 백업 폴더 접근 성공:")
        print(f"   - 폴더 ID: {folder_info.get('id')}")
        print(f"   - 폴더 이름: {folder_info.get('name')}")
        
        # 5. 폴더 내 파일 목록 확인
        print("\n5. 기존 백업 파일 목록:")
        results = service.files().list(
            q=f"parents='{GOOGLE_DRIVE_FOLDER_ID}'",
            fields='files(id,name,size,createdTime)',
            orderBy='createdTime desc',
            pageSize=10
        ).execute()
        
        files = results.get('files', [])
        if files:
            for i, file in enumerate(files, 1):
                file_size = int(file.get('size', 0)) / (1024 * 1024)  # MB
                created_time = file.get('createdTime', 'Unknown')[:10]  # YYYY-MM-DD
                print(f"   {i}. {file.get('name')} ({file_size:.2f} MB, {created_time})")
        else:
            print("   📁 폴더가 비어있습니다.")
        
        print("\n🎉 모든 테스트 통과! Google Drive 백업 시스템이 정상적으로 설정되었습니다.")
        return True
        
    except Exception as e:
        print(f"❌ Google Drive API 연결 실패: {e}")
        print("\n🔍 해결 방법:")
        print("1. Google Drive API가 활성화되어 있는지 확인")
        print("2. 서비스 계정이 백업 폴더에 편집자 권한을 가지고 있는지 확인") 
        print("3. 인증 파일(JSON)이 올바른 서비스 계정의 것인지 확인")
        return False

def main():
    success = test_google_drive_connection()
    
    if success:
        print("\n✨ 다음 단계:")
        print("1. 'python backup-to-google-drive.py' 명령으로 수동 백업 테스트")
        print("2. Windows 작업 스케줄러로 자동 백업 설정")
        sys.exit(0)
    else:
        print("\n💡 setup-google-drive-api.md 파일을 참고하여 설정을 확인해주세요.")
        sys.exit(1)

if __name__ == "__main__":
    main()